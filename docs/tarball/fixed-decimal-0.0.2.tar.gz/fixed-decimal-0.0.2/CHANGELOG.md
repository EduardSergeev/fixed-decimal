# Changelog for `fixed-decimal`

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to the
[Haskell Package Versioning Policy](https://pvp.haskell.org/).

## [0.0.2] - 2024-06-26
### Added
* Basic functionality exposed via `Decimal (m :: Type) (s :: Nat)` type
* Test suite
* Benchmark suite
